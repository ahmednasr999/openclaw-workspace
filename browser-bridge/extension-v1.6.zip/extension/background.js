/**
 * NASR Browser Bridge - Chrome Extension Background Service Worker
 * Connects to VPS WebSocket, receives navigate commands, navigates existing tabs
 */

const BRIDGE_URL = 'ws://76.13.46.115:3010';
const RECONNECT_DELAY_MS = 5000;

let ws = null;
let reconnectTimer = null;
let connected = false;

// The "primary agent tab" - always reuse this tab for all navigations.
// This keeps the DevTools targetId stable so browser.proxy can always snapshot it.
let primaryTabId = null;

async function navigateTab(url) {
  // If we have a primary tab, navigate it in-place (same DevTools targetId)
  if (primaryTabId !== null) {
    try {
      const tab = await chrome.tabs.update(primaryTabId, { url, active: true });
      console.log(`[nasr-bridge] Navigated primary tab ${primaryTabId} to:`, url);
      return tab;
    } catch (e) {
      // Tab may have been closed - fall through to create a new one
      console.warn(`[nasr-bridge] Primary tab ${primaryTabId} gone, creating new:`, e.message);
      primaryTabId = null;
    }
  }

  // First use or tab was closed — find any existing non-devtools tab to adopt
  const allTabs = await chrome.tabs.query({ currentWindow: true });
  const candidate = allTabs.find(t => t.url && !t.url.startsWith('chrome') && !t.url.startsWith('devtools'));

  let tab;
  if (candidate) {
    primaryTabId = candidate.id;
    tab = await chrome.tabs.update(primaryTabId, { url, active: true });
    console.log(`[nasr-bridge] Adopted tab ${primaryTabId} as primary, navigating to:`, url);
  } else {
    tab = await chrome.tabs.create({ url, active: true });
    primaryTabId = tab.id;
    console.log(`[nasr-bridge] Created primary tab ${primaryTabId} for:`, url);
  }

  return tab;
}

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
    return;
  }

  console.log('[nasr-bridge] Connecting to', BRIDGE_URL);
  ws = new WebSocket(BRIDGE_URL);

  ws.onopen = () => {
    connected = true;
    console.log('[nasr-bridge] Connected to VPS');
    clearTimeout(reconnectTimer);
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  };

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log('[nasr-bridge] Received:', msg);

      if (msg.type === 'navigate' && msg.url) {
        console.log('[nasr-bridge] Navigating to:', msg.url);

        const tab = await navigateTab(msg.url);

        // Send back confirmation
        ws.send(JSON.stringify({
          type: 'tab_navigated',
          tabId: tab ? tab.id : null,
          url: msg.url,
          id: msg.id,
          reused: true
        }));
      }

      // Eval JS in the primary tab and return result
      if (msg.type === 'eval' && msg.code) {
        console.log('[nasr-bridge] Eval in primary tab');
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          // We can't pass dynamic functions directly, so wrap code as a string eval
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: (code) => {
              return new Promise(async (resolve) => {
                try {
                  // eslint-disable-next-line no-eval
                  const result = await eval(`(async () => { ${code} })()`);
                  resolve({ ok: true, result: typeof result === 'string' ? result : JSON.stringify(result) });
                } catch (e) {
                  resolve({ ok: false, error: e.message });
                }
              });
            },
            args: [msg.code]
          });

          const r = results[0]?.result || { ok: false, error: 'No result' };
          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ...r }));
        } catch (e) {
          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ok: false, error: e.message }));
        }
      }

      // Read the current tab's DOM text (after navigating to a URL)
      if (msg.type === 'read_dom') {
        console.log('[nasr-bridge] Reading DOM from primary tab');
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => document.documentElement.innerText || document.documentElement.textContent || ''
          });

          const text = results[0]?.result || '';
          ws.send(JSON.stringify({
            type: 'read_dom_result',
            id: msg.id,
            body: text,
            length: text.length
          }));
        } catch (e) {
          ws.send(JSON.stringify({
            type: 'read_dom_result',
            id: msg.id,
            body: '',
            error: e.message
          }));
        }
      }

      if (msg.type === 'fetch' && msg.url) {
        console.log('[nasr-bridge] Fetching URL via tab injection:', msg.url);
        try {
          // Inject fetch into the primary YouTube tab so it runs same-origin
          // and can read YouTube responses (bypasses CORS restrictions in SW)
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: async (fetchUrl) => {
              try {
                const r = await fetch(fetchUrl, { credentials: 'include' });
                const text = await r.text();
                return { status: r.status, ok: r.ok, body: text };
              } catch (e) {
                return { status: 0, ok: false, error: e.message, body: '' };
              }
            },
            args: [msg.url]
          });

          const result = results[0]?.result || { status: 0, ok: false, body: '', error: 'No result' };
          ws.send(JSON.stringify({
            type: 'fetch_result',
            id: msg.id,
            url: msg.url,
            ...result
          }));
        } catch (e) {
          ws.send(JSON.stringify({
            type: 'fetch_result',
            id: msg.id,
            url: msg.url,
            status: 0,
            ok: false,
            error: e.message
          }));
        }
      }
    } catch (e) {
      console.error('[nasr-bridge] Message error:', e);
    }
  };

  ws.onclose = () => {
    connected = false;
    console.log('[nasr-bridge] Disconnected, reconnecting in', RECONNECT_DELAY_MS, 'ms');
    chrome.action.setBadgeText({ text: '○' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    reconnectTimer = setTimeout(connect, RECONNECT_DELAY_MS);
  };

  ws.onerror = () => ws.close();

  ws.send && ws.send;
}

// Start connection
connect();

// Keep alive
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive') {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) connect();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getStatus') {
    sendResponse({ connected, readyState: ws ? ws.readyState : -1 });
  }
  return true;
});
