/**
 * NASR Browser Bridge - Chrome Extension Background Service Worker v2.2
 * Two-step transcript: extract URL from page MAIN world, fetch from service worker
 */

const BRIDGE_URL = 'ws://76.13.46.115:3010';
const RECONNECT_DELAY_MS = 5000;

let ws = null;
let reconnectTimer = null;
let connected = false;
let primaryTabId = null;

async function navigateTab(url) {
  if (primaryTabId !== null) {
    try {
      const tab = await chrome.tabs.update(primaryTabId, { url, active: true });
      console.log(`[nasr-bridge] Navigated primary tab ${primaryTabId} to:`, url);
      return tab;
    } catch (e) {
      console.warn(`[nasr-bridge] Primary tab ${primaryTabId} gone:`, e.message);
      primaryTabId = null;
    }
  }
  const allTabs = await chrome.tabs.query({ currentWindow: true });
  const candidate = allTabs.find(t => t.url && !t.url.startsWith('chrome') && !t.url.startsWith('devtools'));
  let tab;
  if (candidate) {
    primaryTabId = candidate.id;
    tab = await chrome.tabs.update(primaryTabId, { url, active: true });
  } else {
    tab = await chrome.tabs.create({ url, active: true });
    primaryTabId = tab.id;
  }
  return tab;
}

function waitForTabLoad(tabId, timeoutMs = 15000) {
  return new Promise((resolve) => {
    const deadline = Date.now() + timeoutMs;
    function check() {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) { resolve(false); return; }
        if (tab.status === 'complete') { resolve(true); return; }
        if (Date.now() > deadline) { resolve(false); return; }
        setTimeout(check, 300);
      });
    }
    check();
  });
}

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;

  console.log('[nasr-bridge] Connecting to', BRIDGE_URL);
  ws = new WebSocket(BRIDGE_URL);

  ws.onopen = () => {
    connected = true;
    clearTimeout(reconnectTimer);
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    console.log('[nasr-bridge] Connected');
  };

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log('[nasr-bridge] Received:', msg.type, msg.id || '');

      // --- NAVIGATE ---
      if (msg.type === 'navigate' && msg.url) {
        const tab = await navigateTab(msg.url);
        ws.send(JSON.stringify({ type: 'tab_navigated', tabId: tab?.id, url: msg.url, id: msg.id, reused: true }));
      }

      // --- GET_YT_TRANSCRIPT ---
      // Step 1: extract caption URL from page MAIN world (has access to ytInitialPlayerResponse)
      // Step 2: fetch actual transcript bytes from service worker (no CORS/opaque issues)
      if (msg.type === 'get_yt_transcript') {
        console.log('[nasr-bridge] Getting YouTube transcript');
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab');

          // Wait for page load + JS init
          await waitForTabLoad(tabId, 15000);
          await new Promise(r => setTimeout(r, 2000));

          // Step 1: get caption URL from page
          const step1 = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: async () => {
              let player = null;
              for (let i = 0; i < 50; i++) {
                player = window.ytInitialPlayerResponse;
                if (player && player.videoDetails) break;
                await new Promise(r => setTimeout(r, 200));
              }
              if (!player) return { ok: false, error: 'NO_PLAYER_RESPONSE' };
              const tracks = player?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
              if (!tracks?.length) return { ok: false, error: 'NO_CAPTION_TRACKS', title: player.videoDetails?.title };
              const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
              if (!track.baseUrl) return { ok: false, error: 'NO_BASE_URL' };
              return { ok: true, baseUrl: track.baseUrl, lang: track.languageCode, trackName: track.name?.simpleText, title: player.videoDetails?.title };
            }
          });

          const info = step1[0]?.result;
          if (!info?.ok) {
            ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ...(info || { ok: false, error: 'step1 null' }) }));
            return;
          }

          console.log('[nasr-bridge] Got caption URL, fetching from SW...');

          // Step 2: click "Show transcript" and read the panel from DOM
          const step2 = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: async () => {
              const sleep = ms => new Promise(r => setTimeout(r, ms));

              // Helper: find transcript button in player
              function findTranscriptBtn() {
                // Try the "..." button menu first, then direct transcript button
                const btns = [...document.querySelectorAll('button, yt-button-shape button, tp-yt-paper-button')];
                return btns.find(b => (b.getAttribute('aria-label') || b.textContent || '').toLowerCase().includes('transcript'));
              }

              // If panel already open, read it directly
              function readPanel() {
                const segs = document.querySelectorAll('ytd-transcript-segment-renderer');
                if (segs.length === 0) return null;
                return [...segs].map(s => {
                  const text = s.querySelector('.segment-text, .ytd-transcript-segment-renderer');
                  return text ? text.textContent.trim() : s.textContent.trim();
                }).filter(Boolean).join(' ');
              }

              // Check if already open
              let existing = readPanel();
              if (existing) return { ok: true, result: existing, method: 'dom_existing' };

              // Click the "..." menu button (ytd-menu-renderer)
              const menuBtns = document.querySelectorAll('#info-contents ytd-menu-renderer button, ytd-video-primary-info-renderer ytd-menu-renderer button');
              for (const btn of menuBtns) {
                btn.click();
                await sleep(800);
                const transcriptItem = [...document.querySelectorAll('ytd-menu-service-item-renderer, tp-yt-paper-item')]
                  .find(el => el.textContent.toLowerCase().includes('transcript'));
                if (transcriptItem) {
                  transcriptItem.click();
                  await sleep(2000);
                  const result = readPanel();
                  if (result) return { ok: true, result, method: 'dom_menu' };
                  break;
                }
                // Close menu if transcript not found
                document.body.click();
                await sleep(300);
              }

              // Try direct transcript button
              const directBtn = findTranscriptBtn();
              if (directBtn) {
                directBtn.click();
                await sleep(2000);
                const result = readPanel();
                if (result) return { ok: true, result, method: 'dom_direct' };
              }

              // Try ytd-watch-flexy engagement panels
              const engagementBtns = document.querySelectorAll('ytd-button-renderer button');
              for (const btn of engagementBtns) {
                if ((btn.getAttribute('aria-label') || btn.textContent || '').toLowerCase().includes('transcript')) {
                  btn.click();
                  await sleep(2000);
                  const result = readPanel();
                  if (result) return { ok: true, result, method: 'dom_engagement' };
                }
              }

              // Last try: query ALL buttons for transcript-like text
              const allBtns = [...document.querySelectorAll('button, [role="button"]')];
              const transcriptBtns = allBtns.filter(b => {
                const label = (b.getAttribute('aria-label') || b.textContent || b.title || '').toLowerCase();
                return label.includes('transcript');
              });

              for (const btn of transcriptBtns) {
                btn.click();
                await sleep(2000);
                const result = readPanel();
                if (result) return { ok: true, result, method: 'dom_search' };
              }

              return { ok: false, error: 'DOM_PANEL_NOT_FOUND', panelCount: document.querySelectorAll('ytd-transcript-segment-renderer').length, transcriptBtnsFound: transcriptBtns.length };
            }
          });

          const step2result = step2[0]?.result;
          if (step2result?.ok) {
            ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ...step2result, lang: info.lang, title: info.title }));
            return;
          }

          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ok: false, error: 'ALL_METHODS_FAILED', domError: step2result, baseUrl: info.baseUrl }));
        } catch(e) {
          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ok: false, error: e.message }));
        }
      }

      // --- READ_DOM ---
      if (msg.type === 'read_dom') {
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab');
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => document.documentElement.innerText || document.documentElement.textContent || ''
          });
          const text = results[0]?.result || '';
          ws.send(JSON.stringify({ type: 'read_dom_result', id: msg.id, body: text, length: text.length }));
        } catch(e) {
          ws.send(JSON.stringify({ type: 'read_dom_result', id: msg.id, body: '', error: e.message }));
        }
      }

      // --- FETCH ---
      if (msg.type === 'fetch' && msg.url) {
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab');
          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: async (fetchUrl) => {
              try {
                const r = await fetch(fetchUrl, { credentials: 'include' });
                return { status: r.status, ok: r.ok, body: await r.text() };
              } catch(e) {
                return { status: 0, ok: false, error: e.message, body: '' };
              }
            },
            args: [msg.url]
          });
          const result = results[0]?.result || { status: 0, ok: false, body: '', error: 'No result' };
          ws.send(JSON.stringify({ type: 'fetch_result', id: msg.id, url: msg.url, ...result }));
        } catch(e) {
          ws.send(JSON.stringify({ type: 'fetch_result', id: msg.id, url: msg.url, status: 0, ok: false, error: e.message }));
        }
      }

    } catch(e) {
      console.error('[nasr-bridge] Message error:', e);
    }
  };

  ws.onclose = () => {
    connected = false;
    chrome.action.setBadgeText({ text: '○' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    reconnectTimer = setTimeout(connect, RECONNECT_DELAY_MS);
  };

  ws.onerror = () => ws.close();
}

connect();

chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive' && (!connected || !ws || ws.readyState !== WebSocket.OPEN)) connect();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getStatus') sendResponse({ connected, readyState: ws ? ws.readyState : -1 });
  return true;
});
