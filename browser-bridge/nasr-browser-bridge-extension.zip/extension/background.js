/**
 * NASR Browser Bridge - Chrome Extension Background Service Worker
 * Connects to VPS WebSocket, receives navigate commands, navigates existing tabs
 */

const BRIDGE_URL = 'ws://76.13.46.115:3010';
const RECONNECT_DELAY_MS = 5000;

let ws = null;
let reconnectTimer = null;
let connected = false;

async function navigateTab(url) {
  // Try to find an existing tab on the same hostname to navigate in-place
  // This keeps the DevTools targetId stable for browser.proxy
  const urlObj = new URL(url);
  const hostname = urlObj.hostname; // e.g. "x.com"

  // Query for existing tabs on same host
  const existingTabs = await chrome.tabs.query({ url: `*://${hostname}/*` });

  let tab;
  if (existingTabs.length > 0) {
    // Navigate the first matching tab in-place (keeps same targetId)
    tab = await chrome.tabs.update(existingTabs[0].id, { url, active: true });
    console.log(`[nasr-bridge] Navigated existing tab ${existingTabs[0].id} to:`, url);
  } else {
    // No existing tab on this host — create new one
    tab = await chrome.tabs.create({ url, active: true });
    console.log(`[nasr-bridge] Created new tab ${tab.id} for:`, url);
  }

  return tab;
}

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
    return;
  }

  console.log('[nasr-bridge] Connecting to', BRIDGE_URL);
  ws = new WebSocket(BRIDGE_URL);

  ws.onopen = () => {
    connected = true;
    console.log('[nasr-bridge] Connected to VPS');
    clearTimeout(reconnectTimer);
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  };

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log('[nasr-bridge] Received:', msg);

      if (msg.type === 'navigate' && msg.url) {
        console.log('[nasr-bridge] Navigating to:', msg.url);

        const tab = await navigateTab(msg.url);

        // Send back confirmation
        ws.send(JSON.stringify({
          type: 'tab_navigated',
          tabId: tab ? tab.id : null,
          url: msg.url,
          id: msg.id,
          reused: true
        }));
      }
    } catch (e) {
      console.error('[nasr-bridge] Message error:', e);
    }
  };

  ws.onclose = () => {
    connected = false;
    console.log('[nasr-bridge] Disconnected, reconnecting in', RECONNECT_DELAY_MS, 'ms');
    chrome.action.setBadgeText({ text: '○' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    reconnectTimer = setTimeout(connect, RECONNECT_DELAY_MS);
  };

  ws.onerror = () => ws.close();

  ws.send && ws.send;
}

// Start connection
connect();

// Keep alive
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive') {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) connect();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getStatus') {
    sendResponse({ connected, readyState: ws ? ws.readyState : -1 });
  }
  return true;
});
