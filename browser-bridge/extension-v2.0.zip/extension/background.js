/**
 * NASR Browser Bridge - Chrome Extension Background Service Worker
 * Connects to VPS WebSocket, receives navigate commands, navigates existing tabs
 */

const BRIDGE_URL = 'ws://76.13.46.115:3010';
const RECONNECT_DELAY_MS = 5000;

let ws = null;
let reconnectTimer = null;
let connected = false;

// The "primary agent tab" - always reuse this tab for all navigations.
// This keeps the DevTools targetId stable so browser.proxy can always snapshot it.
let primaryTabId = null;

async function navigateTab(url) {
  // If we have a primary tab, navigate it in-place (same DevTools targetId)
  if (primaryTabId !== null) {
    try {
      const tab = await chrome.tabs.update(primaryTabId, { url, active: true });
      console.log(`[nasr-bridge] Navigated primary tab ${primaryTabId} to:`, url);
      return tab;
    } catch (e) {
      console.warn(`[nasr-bridge] Primary tab ${primaryTabId} gone, creating new:`, e.message);
      primaryTabId = null;
    }
  }

  const allTabs = await chrome.tabs.query({ currentWindow: true });
  const candidate = allTabs.find(t => t.url && !t.url.startsWith('chrome') && !t.url.startsWith('devtools'));

  let tab;
  if (candidate) {
    primaryTabId = candidate.id;
    tab = await chrome.tabs.update(primaryTabId, { url, active: true });
    console.log(`[nasr-bridge] Adopted tab ${primaryTabId} as primary, navigating to:`, url);
  } else {
    tab = await chrome.tabs.create({ url, active: true });
    primaryTabId = tab.id;
    console.log(`[nasr-bridge] Created primary tab ${primaryTabId} for:`, url);
  }

  return tab;
}

// Wait for a tab to finish loading
function waitForTabLoad(tabId, timeoutMs = 15000) {
  return new Promise((resolve) => {
    const deadline = Date.now() + timeoutMs;

    function checkStatus() {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) { resolve(false); return; }
        if (tab.status === 'complete') { resolve(true); return; }
        if (Date.now() > deadline) { resolve(false); return; }
        setTimeout(checkStatus, 300);
      });
    }
    checkStatus();
  });
}

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
    return;
  }

  console.log('[nasr-bridge] Connecting to', BRIDGE_URL);
  ws = new WebSocket(BRIDGE_URL);

  ws.onopen = () => {
    connected = true;
    console.log('[nasr-bridge] Connected to VPS');
    clearTimeout(reconnectTimer);
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
  };

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log('[nasr-bridge] Received:', msg.type, msg.id || '');

      if (msg.type === 'navigate' && msg.url) {
        console.log('[nasr-bridge] Navigating to:', msg.url);
        const tab = await navigateTab(msg.url);
        ws.send(JSON.stringify({
          type: 'tab_navigated',
          tabId: tab ? tab.id : null,
          url: msg.url,
          id: msg.id,
          reused: true
        }));
      }

      // get_yt_transcript - extracts YouTube transcript from current tab
      if (msg.type === 'get_yt_transcript') {
        console.log('[nasr-bridge] Getting YouTube transcript from tab');
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          // Wait for tab to finish loading
          console.log('[nasr-bridge] Waiting for tab to load...');
          await waitForTabLoad(tabId, 15000);
          // Extra buffer for YouTube's JS to initialize
          await new Promise(r => setTimeout(r, 2000));

          const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            func: async () => {
              try {
                // Poll for ytInitialPlayerResponse up to 10 seconds
                let player = null;
                for (let i = 0; i < 50; i++) {
                  player = window.ytInitialPlayerResponse;
                  if (player && player.videoDetails) break;
                  await new Promise(r => setTimeout(r, 200));
                }

                if (!player) return { ok: false, error: 'NO_PLAYER_RESPONSE_AFTER_WAIT' };
                if (!player.videoDetails) return { ok: false, error: 'PLAYER_NO_VIDEO_DETAILS', keys: Object.keys(player).join(',') };

                const tracks = player?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
                if (!tracks || tracks.length === 0) {
                  return { ok: false, error: 'NO_CAPTION_TRACKS', title: player.videoDetails?.title };
                }

                const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
                const baseUrl = track.baseUrl;
                if (!baseUrl) return { ok: false, error: 'NO_BASE_URL' };

                // Try json3 first, fall back to XML
                const urlJson = baseUrl + '&fmt=json3';
                const urlXml = baseUrl;

                let lines = [];
                let parseMethod = '';

                // Attempt 1: json3
                try {
                  const r1 = await fetch(urlJson);
                  const raw1 = await r1.text();
                  if (raw1 && raw1.trim().startsWith('{')) {
                    const data = JSON.parse(raw1);
                    const events = data.events || [];
                    for (const e of events) {
                      const segs = e.segs || [];
                      const text = segs.map(s => s.utf8 || '').join('').trim().replace(/\n/g, ' ');
                      if (text) lines.push(text);
                    }
                    parseMethod = 'json3';
                  }
                } catch(e) { /* fall through */ }

                // Attempt 2: XML if json3 failed
                if (lines.length === 0) {
                  try {
                    const r2 = await fetch(urlXml);
                    const raw2 = await r2.text();
                    const matches = raw2.match(/<text[^>]*>([^<]*)<\/text>/g) || [];
                    for (const m of matches) {
                      const t = m.replace(/<[^>]+>/g,'')
                        .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
                        .replace(/&quot;/g,'"').replace(/&#39;/g,"'").trim();
                      if (t) lines.push(t);
                    }
                    parseMethod = 'xml';
                  } catch(e) { /* fall through */ }
                }

                if (lines.length === 0) return { ok: false, error: 'EMPTY_TRANSCRIPT_BOTH_FORMATS', baseUrl };

                return {
                  ok: true,
                  result: lines.join(' '),
                  lang: track.languageCode,
                  trackName: track.name?.simpleText,
                  title: player.videoDetails?.title,
                  method: parseMethod
                };
              } catch (e) {
                return { ok: false, error: e.message };
              }
            }
          });

          const r = results[0]?.result || { ok: false, error: 'No result from scripting' };
          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ...r }));
        } catch (e) {
          ws.send(JSON.stringify({ type: 'eval_result', id: msg.id, ok: false, error: e.message }));
        }
      }

      // Read the current tab's DOM text
      if (msg.type === 'read_dom') {
        console.log('[nasr-bridge] Reading DOM from primary tab');
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => document.documentElement.innerText || document.documentElement.textContent || ''
          });

          const text = results[0]?.result || '';
          ws.send(JSON.stringify({ type: 'read_dom_result', id: msg.id, body: text, length: text.length }));
        } catch (e) {
          ws.send(JSON.stringify({ type: 'read_dom_result', id: msg.id, body: '', error: e.message }));
        }
      }

      if (msg.type === 'fetch' && msg.url) {
        console.log('[nasr-bridge] Fetching URL via tab injection:', msg.url);
        try {
          const tabId = primaryTabId;
          if (!tabId) throw new Error('No primary tab available');

          const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: async (fetchUrl) => {
              try {
                const r = await fetch(fetchUrl, { credentials: 'include' });
                const text = await r.text();
                return { status: r.status, ok: r.ok, body: text };
              } catch (e) {
                return { status: 0, ok: false, error: e.message, body: '' };
              }
            },
            args: [msg.url]
          });

          const result = results[0]?.result || { status: 0, ok: false, body: '', error: 'No result' };
          ws.send(JSON.stringify({ type: 'fetch_result', id: msg.id, url: msg.url, ...result }));
        } catch (e) {
          ws.send(JSON.stringify({ type: 'fetch_result', id: msg.id, url: msg.url, status: 0, ok: false, error: e.message }));
        }
      }
    } catch (e) {
      console.error('[nasr-bridge] Message error:', e);
    }
  };

  ws.onclose = () => {
    connected = false;
    console.log('[nasr-bridge] Disconnected, reconnecting in', RECONNECT_DELAY_MS, 'ms');
    chrome.action.setBadgeText({ text: '○' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    reconnectTimer = setTimeout(connect, RECONNECT_DELAY_MS);
  };

  ws.onerror = () => ws.close();
}

// Start connection
connect();

// Keep alive
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepalive') {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) connect();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getStatus') {
    sendResponse({ connected, readyState: ws ? ws.readyState : -1 });
  }
  return true;
});
