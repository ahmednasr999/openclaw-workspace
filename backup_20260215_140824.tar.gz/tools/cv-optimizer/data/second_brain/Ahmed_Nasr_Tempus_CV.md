# CV - Tempus - VP Product & Operations

**Type:** CV
**Target:** Tempus - VP Product & Operations
**Created:** 2026-02-15T07:45:00Z

**Tags:** cv, job_application, executive, healthcare, digital_transformation

---

AHMED NASR, MBA (In Progress), PMP, CSM, CBAP, MCAD, MCP, Lean Six Sigma
PMO & AI Automation Leader

+971 50 281 4490 (UAE) | +20 128 573 3991 (Egypt)
ahmednasr999@gmail.com | linkedin.com/in/ahmednasr

================================================================================
PROFESSIONAL SUMMARY
================================================================================

A distinguished Digital Transformation Leader and HealthTech AI Expert with over 
20 years of experience driving innovation at the intersection of healthcare, 
artificial intelligence, and digital transformation. Currently leading 
enterprise-wide digital transformation and AI/ML initiatives at Saudi German 
Hospital Group, implementing precision medicine solutions, predictive analytics, 
and clinical decision support systems using Health Catalyst and advanced AI 
technologies. Proven track record leading digital transformation programs, 
scaling products from research to commercial deployment, managing $25M+ P&L, 
and leading cross-functional teams of 50+ across multiple countries. Former 
leadership roles at PaySky, El Araby Group, Talabat, and EMP driving digital 
transformation, operational excellence, and technology innovation in high-growth 
environments.

================================================================================
CORE COMPETENCIES
================================================================================

Digital Transformation • AI/ML Product Development • Precision Medicine • 
HealthTech Innovation • Health Catalyst & Analytics • Clinical Decision Support • 
Product Operations • Predictive Analytics • Machine Learning Implementation • 
Research to Commercial Scale • PMO Leadership • P&L Management • 
Cross-Functional Team Leadership • Strategic Planning • Startup Scaling • 
Healthcare Digital Strategy • Regulatory Compliance (HIPAA)

================================================================================
PROFESSIONAL EXPERIENCE
================================================================================

ACTING PMO & REGIONAL ENGAGEMENT LEAD
TopMed - Saudi German Hospital Group (SGH) | KSA, UAE & Egypt | June 2024 - Present

Leading HealthTech AI & Precision Medicine Initiatives Across SGH Group

• Spearheading enterprise-wide AI/ML and precision medicine initiatives to 
  modernize hospital operations and enhance patient care across 10+ hospitals
• Leading implementation of Health Catalyst's Enterprise Data Warehouse (EDW) 
  & AI-powered Analytics for real-time clinical insights and predictive modeling
• Deploying AI-driven Clinical Decision Support (CDS) tools to enhance 
  diagnostics, reduce clinical variation, and personalize treatment pathways
• Managing $25M+ P&L for AI and digital transformation programs across 
  regional hospitals serving 500K+ patients annually
• Scaling AI products from pilot research phase to full commercial deployment 
  across multi-site healthcare network
• Building and leading cross-functional product and engineering teams of 50+ 
  professionals across 4 countries
• Implementing precision medicine platforms using machine learning models 
  to predict patient outcomes and optimize treatment protocols
• Ensuring HIPAA compliance and alignment with healthcare quality standards

Key AI/ML Projects:
• AI & Predictive Analytics Platform – Integrated ML models for patient risk 
  stratification and outcome prediction
• Precision Medicine Decision Support – Deployed AI tools for personalized 
  treatment recommendations
• Clinical Data Intelligence – Implemented real-time analytics for population 
  health management
• AI Product Scaling – Took pilot AI solutions to enterprise-wide deployment

---

COUNTRY MANAGER
PaySky & Yalla SuperApp (Acquired by ENPO) | Apr 2021 - Jan 2022

• Managed P&L and achieved financial OKRs for fintech super app, driving 
  revenue growth in high-growth startup environment
• Built world-class Go-To-Market team and scaled operations from launch to 
  market leadership position
• Directed product strategy through data analytics, market mapping, and 
  customer insights
• Led cross-functional teams in agile, fast-paced startup environment

---

HEAD OF STRATEGY & VP ADVISOR
El Araby Group | Jan 2020 - Dec 2021

• Led digital transformation and ERP implementation (SAP S/4HANA) across 
  enterprise with $100M+ revenue
• Implemented Araby Hospital Health ERP System (Mayo Clinic-grade system)
• Developed multi-year strategic plans and advised C-suite on technology 
  investments and operational improvements
• Managed stakeholder relationships across medical, technical, and executive teams

---

PRODUCT DEVELOPMENT MANAGER
Talabat, Delivery Hero SE | Jun 2017 - May 2018

• Scaled product operations from 30K to 7M daily orders across MENA region
• Established and led Egypt office with full P&L responsibility
• Managed product roadmap and coordinated between Berlin HQ and regional teams
• Implemented data-driven features and operational excellence programs

---

CEO & BUSINESS PARTNER
Soleek Lab | May 2018 - Jul 2019

• Led product development and go-to-market strategy for tech startup
• Drove business growth through innovative AI and automation solutions
• Managed end-to-end product lifecycle from concept to commercial launch

---

PMO SECTION HEAD
EMP (Acquired by Network International) | Sep 2014 - Jun 2017

• Built PMO function from scratch, managing 300+ concurrent technology projects
• Implemented Microsoft Project Server and established agile/scrum methodologies
• Developed strategic dashboards for real-time decision making
• Increased organizational net profit threefold through operational efficiency

================================================================================
CERTIFICATIONS
================================================================================

Project Management Professional (PMP) | Certified Scrum Master (CSM) | 
Certified Business Analysis Professional (CBAP) | Microsoft Certified 
Application Developer (MCAD) | Microsoft Certified Professional (MCP) | 
Lean Six Sigma Certified

================================================================================
EDUCATION
================================================================================

Master's in Business Administration (MBA) - In Progress
Sadat Academy for Management Sciences

BSc. Computer Sciences & Business Administration
Sadat Academy | June 2006

================================================================================
ADDITIONAL INFORMATION
================================================================================

• Published "An FinTech Weekly Newsletter" with 5,000+ subscribers
• Speaker at healthcare AI and digital transformation conferences
• Fluent in English and Arabic
• Available for relocation to USA
• Emirates ID: 143529044

