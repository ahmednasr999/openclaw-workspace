# Cover Letter - Tempus

**Type:** Cover Letter
**Company:** Tempus
**Created:** 2026-02-15T07:45:00Z

**Tags:** cover_letter, job_application, executive

---

Ahmed Nasr
+971 50 281 4490 (UAE) | +20 128 573 3991 (Egypt)
ahmednasr999@gmail.com | linkedin.com/in/ahmednasr

[Date]

Hiring Manager
Tempus

Dear Hiring Manager,

The intersection of digital transformation, AI, and precision medicine represents 
the future of healthcare, and Tempus is clearly leading that transformation. My 
experience implementing Health Catalyst AI solutions and leading digital 
transformation across 10+ hospitals has prepared me to contribute immediately to 
your mission of personalizing cancer care.

At Saudi German Hospital Group, I am driving digital transformation in healthcare AI:
• Implementing Health Catalyst Enterprise Data Warehouse and AI-powered analytics 
  for precision medicine initiatives
• Deploying AI-driven Clinical Decision Support tools for personalized treatment 
  recommendations
• Leading digital transformation from research/pilot phase to full commercial 
  deployment across multi-site network
• Managing $25M+ P&L for AI and digital health programs
• Building cross-functional product and engineering teams of 50+

My background offers Tempus:
• Digital transformation leadership in healthcare AI and precision medicine
• AI/ML product development and scaling (Health Catalyst, predictive analytics)
• Experience taking AI solutions from research to commercial deployment
• Healthcare operations and regulatory compliance (HIPAA, JCI)
• Enterprise experience with startup agility (PaySky, Soleek Lab)
• P&L management and cross-functional team leadership

What distinguishes my background is leading digital transformation initiatives 
that bridge enterprise-scale operations (SGH, El Araby Group) with high-growth 
innovation (PaySky, Talabat scaling). I understand how to build and scale AI 
products that work technically and drive real clinical value.

I am excited about the opportunity to contribute to Tempus's mission of 
personalizing cancer care through AI and digital transformation.

Thank you for your consideration.

Sincerely,

Ahmed Nasr, MBA (In Progress), PMP
Digital Transformation Leader & PMO Director

