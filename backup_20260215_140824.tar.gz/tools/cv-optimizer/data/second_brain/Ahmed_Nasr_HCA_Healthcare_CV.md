# CV - HCA Healthcare - VP Healthcare AI & Operations

**Type:** CV
**Target:** HCA Healthcare - VP Healthcare AI & Operations
**Created:** 2026-02-15T07:45:00Z

**Tags:** cv, job_application, executive, healthcare, digital_transformation

---

AHMED NASR, MBA (In Progress), PMP, CSM, CBAP, MCAD, MCP, Lean Six Sigma
PMO & AI Automation Leader

+971 50 281 4490 (UAE) | +20 128 573 3991 (Egypt)
ahmednasr999@gmail.com | linkedin.com/in/ahmednasr

================================================================================
PROFESSIONAL SUMMARY
================================================================================

A distinguished Digital Transformation Leader and HealthTech Expert with over 
20 years of experience driving enterprise-wide digital transformation, innovation, 
and operational excellence in healthcare technology. Currently leading 
digital transformation initiatives at Saudi German Hospital Group, implementing 
cutting-edge AI-driven solutions, Health Catalyst analytics platforms, and 
digital patient engagement systems across KSA, UAE, and Egypt. Proven expertise 
in leading large-scale digital transformation programs, scaling healthcare 
operations regionally, establishing PMO frameworks, and delivering transformative 
solutions that align with JCI, HIMSS, and MOH standards. Former leadership roles 
at PaySky, El Araby Group, Talabat, and EMP driving digital transformation, 
operational excellence, and technology innovation.

================================================================================
CORE COMPETENCIES
================================================================================

Digital Transformation • HealthTech & Healthcare AI • Health Catalyst & Analytics • 
Clinical Decision Support • EMR/EHR Systems • SAP S/4HANA Implementation • 
PMO Establishment & Governance • Regional Engagement & Market Expansion • 
AI/ML in Healthcare • Strategic Business Planning • Operational Excellence • 
Team Leadership • Stakeholder Management • JCI & HIMSS Standards • HIPAA Compliance

================================================================================
PROFESSIONAL EXPERIENCE
================================================================================

ACTING PMO & REGIONAL ENGAGEMENT LEAD
TopMed - Saudi German Hospital Group (SGH) | KSA, UAE & Egypt | June 2024 - Present

Leading HealthTech Digital Transformation Across SGH Group with USA partners

• Spearheading enterprise-wide HealthTech initiatives to modernize hospital 
  operations, enhance patient care, and improve clinical efficiency across 
  Saudi German Hospital Group in KSA, UAE, and Egypt
• Leading collaboration with top U.S. healthcare technology providers, including 
  Health Catalyst (advanced analytics, AI-driven decision support) and KLAS Research
• Establishing and managing a structured PMO framework, ensuring seamless execution 
  of large-scale HealthTech projects
• Overseeing implementation of Health Catalyst's Enterprise Data Warehouse (EDW) 
  & Analytics Solutions for real-time insights and predictive analytics
• Leading deployment of AI-driven Clinical Decision Support (CDS) tools to enhance 
  diagnostics and reduce clinical variation
• Implementing next-generation patient engagement platforms, including personalized 
  digital health portals, telemedicine, and mobile health applications
• Utilizing data-driven insights and process automation to streamline workflows 
  and reduce administrative burdens
• Ensuring alignment with international healthcare quality standards (JCI, HIMSS, 
  MOH regulations)

Key Projects:
• Enterprise Data & Analytics Transformation – Implemented advanced Health Catalyst 
  EDW for real-time hospital data intelligence
• AI & Predictive Analytics in Healthcare – Integrated AI-driven Clinical Decision 
  Support (CDS) tools
• Digital Patient Experience Enhancement – Launched telemedicine platforms, mobile 
  apps, and engagement portals
• Hospital Operational Efficiency Program – Optimized workflow automation, reducing 
  costs and improving resource allocation

---

COUNTRY MANAGER
PaySky & Yalla SuperApp (Acquired by ENPO) | Apr 2021 - Jan 2022

• Managed operating budgets and achieved financial OKRs for Yalla SuperApp, driving 
  consistent revenue growth and profitability
• Directed business strategy through market mapping, product strategy, data analytics, 
  and client insights
• Managed and motivated cross-functional teams, overseeing headcount, budgets, and 
  resources
• Enhanced client relationships, closed high-value deals, and implemented up-selling 
  and cross-selling strategies
• Built a world-class Go-To-Market team, ensuring best-in-class B2B and B2C success

---

HEAD OF STRATEGY & VP ADVISOR
El Araby Group | Jan 2020 - Dec 2021

• Led successful implementation of SAP S/4HANA project, streamlining business 
  processes and enhancing operational efficiency
• Led successful implementation of Araby Hospital Health ERP System (same system 
  as Mayo Clinic)
• Developed and communicated multi-year strategic business plans, ensuring 
  organizational alignment
• Advised executive teams on business operations, marketing strategies, and 
  financial planning

---

PRODUCT DEVELOPMENT MANAGER
Talabat, Delivery Hero SE | Jun 2017 - May 2018

• Acted as focal point between Berlin headquarters and MENA region companies, 
  overseeing product development
• Established Egypt office, managing software engineers, account managers, and 
  product managers
• Scaled daily orders from 30K to 7M
• Implemented tracking features and managed operational excellence programs

---

CEO & BUSINESS PARTNER
Soleek Lab | May 2018 - Jul 2019

• Spearheaded business development and strategic planning, driving company growth 
  through innovative project management
• Enhanced operational management, ensuring efficient project delivery and 
  customer satisfaction

---

PMO SECTION HEAD
EMP (Acquired by Network International) | Sep 2014 - Jun 2017

• Built PMO from scratch, managing projects for African banks and ensuring 
  integration with central banks
• Developed strategic dashboard system for proactive decision-making, increasing 
  organizational net profit threefold
• Implemented Microsoft Project Server on cloud, managing 300 concurrent projects 
  and optimizing project life cycles

================================================================================
CERTIFICATIONS
================================================================================

Project Management Professional (PMP) | Certified Scrum Master (CSM) | 
Certified Business Analysis Professional (CBAP) | Microsoft Certified 
Application Developer (MCAD) | Microsoft Certified Professional (MCP) | 
Lean Six Sigma Certified

================================================================================
EDUCATION
================================================================================

Master's in Business Administration (MBA) - In Progress
Sadat Academy for Management Sciences

BSc. Computer Sciences & Business Administration
Sadat Academy | June 2006

================================================================================
ADDITIONAL INFORMATION
================================================================================

• Published "An FinTech Weekly Newsletter" with 5,000+ subscribers
• Speaker at healthcare AI and digital transformation conferences
• Fluent in English and Arabic
• Available for relocation to USA
• Emirates ID: 143529044

