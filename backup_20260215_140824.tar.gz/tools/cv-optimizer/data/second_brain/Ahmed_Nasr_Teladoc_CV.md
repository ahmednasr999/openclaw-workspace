# CV - Teladoc Health - VP Digital Health Operations

**Type:** CV
**Target:** Teladoc Health - VP Digital Health Operations
**Created:** 2026-02-15T07:45:00Z

**Tags:** cv, job_application, executive, healthcare, digital_transformation

---

AHMED NASR, MBA (In Progress), PMP, CSM, CBAP, MCAD, MCP, Lean Six Sigma
Digital Transformation Leader & PMO Director

+971 50 281 4490 (UAE) | +20 128 573 3991 (Egypt)
ahmednasr999@gmail.com | linkedin.com/in/ahmednasr

================================================================================
PROFESSIONAL SUMMARY
================================================================================

A distinguished Digital Transformation Leader and HealthTech Operations Expert 
with over 20 years of experience driving large-scale digital health initiatives 
across healthcare, FinTech, and technology sectors. Currently leading 
enterprise-wide digital transformation at Saudi German Hospital Group, 
implementing telemedicine platforms, virtual care solutions, AI-driven clinical 
decision support, and digital patient engagement systems using Health Catalyst 
and advanced technologies. Proven track record managing $25M+ P&L, scaling 
digital health platforms to serve 500K+ patients, and leading cross-functional 
teams of 50+ across multiple countries. Former leadership roles at PaySky, 
El Araby Group, Talabat, and EMP driving digital transformation and operational 
excellence.

================================================================================
CORE COMPETENCIES
================================================================================

Digital Transformation • Telemedicine & Virtual Care • Digital Health Operations • 
HealthTech Innovation • Health Catalyst & Analytics • AI/ML Implementation • 
Clinical Decision Support • EMR/EHR Systems • Patient Engagement Platforms • 
PMO Leadership & Governance • P&L Management ($25M+) • Cross-Functional Team 
Leadership • Strategic Planning • Operational Excellence • Healthcare Compliance 
(HIPAA, JCI)

================================================================================
PROFESSIONAL EXPERIENCE
================================================================================

ACTING PMO & REGIONAL ENGAGEMENT LEAD
TopMed - Saudi German Hospital Group (SGH) | KSA, UAE & Egypt | June 2024 - Present

Leading Digital Transformation & Virtual Care Initiatives Across SGH Group

• Spearheading enterprise-wide digital transformation to modernize hospital 
  operations, enhance patient care, and improve clinical efficiency across 
  10+ hospitals in KSA, UAE, and Egypt
• Leading implementation of telemedicine platforms, virtual care solutions, 
  and digital patient engagement systems serving 500K+ patients annually
• Deploying Health Catalyst's Enterprise Data Warehouse (EDW) & AI-powered 
  Analytics for real-time clinical insights and predictive modeling
• Implementing AI-driven Clinical Decision Support (CDS) tools to enhance 
  diagnostics, reduce clinical variation, and personalize treatment pathways
• Managing $25M+ P&L for digital transformation and health technology programs
• Building and leading cross-functional teams of 50+ professionals across 
  4 countries to execute digital health initiatives
• Ensuring HIPAA compliance, JCI standards, and alignment with healthcare 
  quality regulations across all digital platforms

Key Digital Transformation Projects:
• Telemedicine & Virtual Care Platform – Launched comprehensive telemedicine 
  solution enabling remote consultations and digital health delivery
• Digital Patient Experience Enhancement – Deployed patient portals, mobile 
  apps, and engagement platforms for 500K+ patients
• Enterprise Data & Analytics Transformation – Implemented Health Catalyst 
  EDW for real-time hospital data intelligence and population health management
• AI & Predictive Analytics – Integrated ML models for patient risk 
  stratification and clinical decision support

---

COUNTRY MANAGER
PaySky & Yalla SuperApp (Acquired by ENPO) | Apr 2021 - Jan 2022

• Led digital transformation and scaling of fintech super app from launch to 
  market leadership position
• Managed P&L and achieved financial OKRs, driving revenue growth through 
  digital innovation
• Built world-class Go-To-Market team and established digital-first operations
• Directed product strategy through data analytics and customer insights

---

HEAD OF STRATEGY & VP ADVISOR
El Araby Group | Jan 2020 - Dec 2021

• Led enterprise-wide digital transformation and SAP S/4HANA implementation 
  across $100M+ revenue organization
• Implemented Araby Hospital Health ERP System (Mayo Clinic-grade system)
• Developed multi-year digital strategy and advised C-suite on technology 
  investments and operational improvements
• Managed stakeholder relationships across medical, technical, and executive teams

---

PRODUCT DEVELOPMENT MANAGER
Talabat, Delivery Hero SE | Jun 2017 - May 2018

• Scaled digital platform operations from 30K to 7M daily orders across MENA 
  through digital transformation initiatives
• Established Egypt office and led digital product development
• Managed product roadmap and coordinated between Berlin HQ and regional teams
• Implemented data-driven features and digital operational excellence programs

---

CEO & BUSINESS PARTNER
Soleek Lab | May 2018 - Jul 2019

• Led digital transformation consulting and technology solutions for clients
• Drove business growth through innovative AI, automation, and digital solutions
• Managed end-to-end digital product lifecycle from concept to commercial launch

---

PMO SECTION HEAD
EMP (Acquired by Network International) | Sep 2014 - Jun 2017

• Built PMO function from scratch, managing 300+ concurrent digital 
  transformation and technology projects
• Implemented Microsoft Project Server and established agile/scrum methodologies
• Developed strategic dashboards for real-time decision making
• Increased organizational net profit threefold through digital operational 
  efficiency

================================================================================
CERTIFICATIONS
================================================================================

Project Management Professional (PMP) | Certified Scrum Master (CSM) | 
Certified Business Analysis Professional (CBAP) | Microsoft Certified 
Application Developer (MCAD) | Microsoft Certified Professional (MCP) | 
Lean Six Sigma Certified

================================================================================
EDUCATION
================================================================================

Master's in Business Administration (MBA) - In Progress
Sadat Academy for Management Sciences

BSc. Computer Sciences & Business Administration
Sadat Academy | June 2006

================================================================================
ADDITIONAL INFORMATION
================================================================================

• Published "An FinTech Weekly Newsletter" with 5,000+ subscribers
• Speaker at healthcare digital transformation and AI conferences
• Fluent in English and Arabic
• Available for relocation to USA
• Emirates ID: 143529044

